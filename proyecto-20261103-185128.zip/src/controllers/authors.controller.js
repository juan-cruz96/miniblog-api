import {
  findAllAuthors,
  findAuthorById,
  insertAuthor,
  updateAuthorById,
  deleteAuthorById,
} from "../services/authors.service.js";
import { validateAuthor } from "../utils/validators.js";

export const getAllAuthors = async (req, res) => {
  try {
    const authors = await findAllAuthors();
    res.status(200).json(authors);
  } catch (error) {
    console.error("Error al buscar autores:", error.message);

    res.status(500).json({
      error: "No se pudieron obtener los autores",
    });
  }
};

export const getAuthorById = async (req, res) => {
  try {
    const id = req.authorId;
    const author = await findAuthorById(id);

    if (!author) {
      return res.status(404).json({
        error: "Autor no encontrado",
      });
    }

    res.status(200).json(author);
  } catch (error) {
    console.error("Error al buscar autor:", error.message);

    res.status(500).json({
      error: "No se pudo obtener el autor",
    });
  }
};

export const createAuthor = async (req, res) => {
  const { name, email, bio = null } = req.body ?? {};

  const validationError = validateAuthor(req.body);

  if (validationError) {
    return res.status(400).json({
      error: validationError,
    });
  }

  try {
    const author = await insertAuthor(name.trim(), email.trim(), bio);

    return res.status(201).json(author);
  } catch (error) {
    if (error.code === "23505" && error.constraint === "authors_email_key") {
      return res.status(400).json({
        error: "Ya existe un autor con ese email",
      });
    }

    console.error("Error al crear autor:", error.message);

    return res.status(500).json({
      error: "No se pudo crear el autor",
    });
  }
};

export const updateAuthor = async (req, res) => {
  const id = req.authorId;
  const { name, email, bio = null } = req.body ?? {};

  const validationError = validateAuthor(req.body);

  if (validationError) {
    return res.status(400).json({
      error: validationError,
    });
  }

  try {
    const author = await updateAuthorById(id, name.trim(), email.trim(), bio);

    if (!author) {
      return res.status(404).json({
        error: "Autor no encontrado",
      });
    }

    return res.status(200).json(author);
  } catch (error) {
    if (error.code === "23505" && error.constraint === "authors_email_key") {
      return res.status(400).json({
        error: "Ya existe un autor con ese email",
      });
    }

    console.error("Error al actualizar autor:", error.message);

    return res.status(500).json({
      error: "No se pudo actualizar el autor",
    });
  }
};

export const deleteAuthor = async (req, res) => {
  try {
    const id = req.authorId;
    const author = await deleteAuthorById(id);

    if (!author) {
      return res.status(404).json({
        error: "Autor no encontrado",
      });
    }

    return res.status(200).json({
      message: "Autor eliminado con éxito",
    });
  } catch (error) {
    if (error.code === "23503" && error.constraint === "posts_author_id_fkey") {
      return res.status(400).json({
        error: "No se puede eliminar un autor que tiene posts asociados",
      });
    }

    console.error("Error al eliminar autor:", error.message);

    return res.status(500).json({
      error: "No se pudo eliminar el autor",
    });
  }
};
